import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Turno } from '../../models/Turno.interface';
import { TurnosService } from '../../services/turnos.service';

@Component({
  selector: 'app-carga-turno',
  templateUrl: './carga-turno.component.html',
  styleUrl: './carga-turno.component.css'
})
export class CargaTurnoComponent {
  @Output() TurnoCancelado = new EventEmitter<boolean>();
  @Output() MenuTurnoCerrado = new EventEmitter<boolean>();

  turno: Turno = {
    id: 0,
    paciente: '',
    fecha: '',
    hora: '',
    estado: 'pendiente'
  }

  @Input() visible: boolean = false;

  error: boolean = false;

  constructor(private turnoService: TurnosService) {}

  crearTurno() {
    this.turnoService.agregarTurno(this.turno);
    
    if (this.turnoService.elTurnoEsValido) {
      this.MenuTurnoCerrado.emit(false);

    } else {
      this.error = true;
    }
  }

  cancelarTurno(): void {
    this.TurnoCancelado.emit();
  }
}
