import { Component, ElementRef, EventEmitter, OnInit, OnDestroy, Output, ViewChild } from '@angular/core';
import { Turno } from '../../models/Turno.interface';
import { TurnosService } from '../../services/turnos.service';
import { TurnoComponent } from '../turno/turno.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-lista-turnos',
  templateUrl: './lista-turnos.component.html',
  styleUrl: './lista-turnos.component.css'
})
export class ListaTurnosComponent implements OnInit {
  turnos: Turno[] = [];
  nuevoTurno!: Turno;
  cargaTurno: boolean = false;

  private turnosSub!: Subscription;
  cargando: boolean = false;

  constructor(private turnosService: TurnosService) {}

  ngOnInit(): void {
    this.cargando = true;
    this.turnosSub = this.turnosService.obtenerTurnos().subscribe({
      next: (data) => {
        this.turnos = data;
        this.cargando = false;
      },
      error: (e) => {
        console.error('burraso',e);
        this.cargando = false;
      }
    });
    console.log(this.turnos);
  }

  confirmar(id: number): void {
    this.turnosService.cambiarEstado(id, 'confirmado');
  }

  cancelar(id: number): void {
    this.turnosService.cambiarEstado(id, 'cancelado');
  }

  modificarEstado(id: number, nuevoEstado: 'pendiente' | 'confirmado' | 'cancelado'): void {
    this.turnosService.cambiarEstado(id, nuevoEstado);
  }

  crearTurno(): void {
    this.turnosService.agregarTurno(this.nuevoTurno);
  }

  cargarTurnos(): void {
    this.cargaTurno = !this.cargaTurno;
  }

  cerrarMenu(valor: boolean) {
    this.cargaTurno = valor;
  }

  ngOnDestroy() {
    this.turnosSub.unsubscribe();
  }
}
