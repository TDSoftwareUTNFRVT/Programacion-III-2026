import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { Turno } from '../../models/Turno.interface';
import { TurnosService } from '../../services/turnos.service';

@Component({
  selector: 'app-turno',
  templateUrl: './turno.component.html',
  styleUrl: './turno.component.css'
})
export class TurnoComponent {
  @Input() turno!: Turno;
  @Input() nuevoTurnoCreadoInput!: boolean;

  @ViewChild('patientCard') patientCard!: ElementRef<HTMLDivElement>;
  @ViewChild('confirmButton') confirmButton!: ElementRef<HTMLButtonElement>;
  @ViewChild('cancelButton') cancelButton!: ElementRef<HTMLButtonElement>;
  @ViewChild('modifyButton') modifyButton!: ElementRef<HTMLButtonElement>;

  constructor(private turnosService: TurnosService) {}

  ngAfterViewInit() {
    this.chequearEstado();
  }

  modificarEstado(id: number, nuevoEstado: 'pendiente' | 'confirmado' | 'cancelado'): void {
    this.turnosService.cambiarEstado(id, nuevoEstado);

    this.chequearEstado();

    console.log(this.turnosService.obtenerTurnos());
  }

  chequearEstado() {
    if (this.turno.estado === 'cancelado') {
      this.patientCard.nativeElement.style.background = '#E33636';
    }

    if (this.turno.estado === 'confirmado') {
      this.patientCard.nativeElement.style.background = '#60A649';
    }

    if (this.turno.estado === 'cancelado' || this.turno.estado === 'confirmado') {
      this.confirmButton.nativeElement.disabled = true;
      this.cancelButton.nativeElement.disabled = true;

      this.confirmButton.nativeElement.hidden = true;
      this.cancelButton.nativeElement.hidden = true;

      this.modifyButton.nativeElement.disabled = false;
      this.modifyButton.nativeElement.hidden = false;
    }

    if (this.turno.estado === 'pendiente') {
      this.patientCard.nativeElement.style.background = 'rgb(124, 124, 212)';

      this.confirmButton.nativeElement.disabled = false;
      this.cancelButton.nativeElement.disabled = false;

      this.confirmButton.nativeElement.hidden = false;
      this.cancelButton.nativeElement.hidden = false;

      this.modifyButton.nativeElement.disabled = true;
      this.modifyButton.nativeElement.hidden = true;
    }
  }
}
