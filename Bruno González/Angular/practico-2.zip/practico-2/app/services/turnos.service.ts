import { Injectable } from '@angular/core';
import { delay, Observable, of } from 'rxjs';
import { Turno } from '../models/Turno.interface';

@Injectable({
  providedIn: 'root'
})
export class TurnosService {
  private turnos: Turno[] = [
    { id: 1, fecha: '2023-10-01', hora: '10:00', paciente: 'Juan Pérez', estado: 'pendiente' },
    { id: 2, fecha: '2023-10-02', hora: '11:00', paciente: 'María López', estado: 'pendiente' },
    { id: 3, fecha: '2023-10-03', hora: '12:00', paciente: 'Carlos García', estado: 'pendiente' },
    { id: 4, fecha: '2023-10-04', hora: '13:00', paciente: 'Ana Torres', estado: 'pendiente' },
    { id: 5, fecha: '2023-10-05', hora: '14:00', paciente: 'Luis Fernández', estado: 'pendiente' },
    { id: 6, fecha: '2023-10-06', hora: '09:30', paciente: 'Sofía Martínez', estado: 'pendiente' },
    { id: 7, fecha: '2023-10-07', hora: '15:00', paciente: 'Diego Ramírez', estado: 'pendiente' },
    { id: 8, fecha: '2023-10-08', hora: '16:30', paciente: 'Valentina Gómez', estado: 'pendiente' },
    { id: 9, fecha: '2023-10-09', hora: '08:00', paciente: 'Martín Herrera', estado: 'pendiente' },
    { id: 10, fecha: '2023-10-10', hora: '17:00', paciente: 'Camila Díaz', estado: 'pendiente' },
    { id: 11, fecha: '2023-10-11', hora: '10:30', paciente: 'Federico Álvarez', estado: 'pendiente' },
    { id: 12, fecha: '2023-10-12', hora: '11:45', paciente: 'Paula Ríos', estado: 'pendiente' },
    { id: 13, fecha: '2023-10-13', hora: '13:15', paciente: 'Julián Castro', estado: 'pendiente' },
    { id: 14, fecha: '2023-10-14', hora: '14:45', paciente: 'Florencia Navarro', estado: 'pendiente' },
    { id: 15, fecha: '2023-10-15', hora: '09:00', paciente: 'Gabriel Suárez', estado: 'pendiente' }
  ];

  elTurnoEsValido: boolean = false;

  constructor() { }

  obtenerTurnos(): Observable<Turno[]> {
    return of(this.turnos).pipe(delay(800));
  }

  obtenerPorId(id: number): Turno | undefined {
    return this.turnos.find(t => t.id === id);
  }

  validarTurno(turno: Turno): boolean {
    if (turno.fecha === '' || turno.hora === '' || turno.paciente === '') {
      this.elTurnoEsValido = false;

    } else {
      this.elTurnoEsValido = true;
    }

    return this.elTurnoEsValido;
  }

  agregarTurno(turno: Turno): void {
    if (this.validarTurno(turno)) {
      turno.id = this.turnos.length + 1;
      this.turnos.push(turno);
      
      console.log(this.turnos);

    } else {
      console.log('CAMPOS INCOMPLETOS >:(');
    }
  }

  cambiarEstado(id: number, nuevoEstado: Turno['estado']): void {
    const turno = this.obtenerPorId(id);

    if (turno) {
      turno.estado = nuevoEstado;
    }
  }

  eliminarTurno(id: number): void {
    this.turnos = this.turnos.filter(t => t.id !== id);
  }
}
