type TipoAppState = "idle" | "loading" | "error" | "empty";
// Tipo literal donde la variable sólo puede tomar uno de estos valores

class AppStatus extends HTMLElement {
    private shadow: ShadowRoot;
    private _state: TipoAppState = "idle";
    // Guarda el estado actual del componente
    private _message: string | null = '';
    // Guarda un mensaje opcional, como por ej un texto de error

    static get observedAttributes(): string[] {
        return ["state", "message"];
    }

    constructor() {
        super();
        this.shadow = this.attachShadow({mode: 'open'});
    }

    connectedCallback(): void {
        this.render();
    }

    attributeChangedCallback(nombre: string | null, anterior: string | null, nuevo: string | null): void {
        if(nombre === "state") {
            this._state = nuevo as TipoAppState;
        }
        
        if(nombre === "message") {
            this._message = nuevo;
        }

        this.render();
    }

    private render(): void {
        let content = "";

        if(this._state === "loading") {
            content = `<div class="spinner"></div>`;
        }

        if(this._state === "error") {
            content = `<div class="error">${this._message}</div>`;
        }

        if(this._state === "empty") {
            content = `<span>No se encontró nada :(</span>`;
        }

        this.shadow.innerHTML = `
            <style>
                :host {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }

                .spinner {
                    border: 4px solid #f3f3f3;
                    border-top: 4px solid #6366f1;
                    border-radius: 50%;
                    width: 30px;
                    height: 30px;
                    animation: spin 1s linear infinite;
                }

                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                .error {
                    color: red;
                    font-weight: bold;
                }
            </style>
            ${content}
        `;
    }
}

customElements.define('app-status', AppStatus);