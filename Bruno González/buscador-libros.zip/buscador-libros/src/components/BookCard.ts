import { Book } from "../models/Book";
import { truncate, JoinList } from "../utils/helpers";

export class BookCard {
    private book: Book;
    // Guarda el libro que se va a mostrar

    constructor(book: Book) {this.book = book}

    public render(): HTMLElement {
        const card = document.createElement("article");
        card.className = 'book-card';
        // Para ponerle la clase book-card a card
        card.setAttribute("data-id", this.book.id);

        card.innerHTML = `
                        <div class="book-cover">
                        <img src="${this.book.coverUrl ?? "/img/no-cover.png"}"
                        alt="${this.escapeHtml(this.book.title)}"
                        loading="lazy" />
                        </div>
                        <div class="book-info">
                        <h3>${this.escapeHtml(truncate(this.book.title, 60))}</h3>
                        <p class="authors">${JoinList(this.book.authors)}</p>
                        <p class="year">${this.book.year ?? "Año desconocido"}</p>
                        <div class="subjects">${this.renderSubjects()}</div>
                        </div>`;

        card.addEventListener("click", () => {
            const evento = new CustomEvent<Book>("book:selected", {
                detail: this.book,
                // El evento lleva dentro el objeto Book completo
                bubbles: true
                // El evento sube por el DOM, así que se puede escuchar en document o en un contenedor, permitiendo que otras partes de la app reaccionen cuando el usuario selecciona un libro
            });

            card.dispatchEvent(evento);
        });
        return card;
    }

    private renderSubjects(): string {
        return this.book.subjects.slice(0, 3).map(s => `<span class="badge">${this.escapeHtml(s)}</span>`).join("");
        // Toma hasta 3 temas del libro, los convierte a una etiqueta span y escapa el texto para evitar inyecciones HTML
    }

    private escapeHtml(text: string): string {
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
        // Técnica para evitar XSS, si el título tuviera <script>, se convierte en texto plano y no se ejecuta
    }

    private handleClick(): void {
        console.log(`Libro seleccionado: ${this.book.title}`);
    }
}