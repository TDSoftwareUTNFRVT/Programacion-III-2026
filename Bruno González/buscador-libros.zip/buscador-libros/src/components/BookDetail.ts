import { Book } from "../models/Book";
import { JoinList, truncate } from "../utils/helpers";

const contenedor_detalle_libro = document.getElementById('book-detail-grid') as HTMLDivElement;

const template = document.createElement('template');

template.innerHTML = `
<style>
    .book-detail {
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;
        overflow: auto;
        overflow-x: hidden;
        justify-content: center;
        align-items: center;
        gap: 15px;
        width: 100%;
        height: 85vh;
        text-align: center;
        text-wrap: pretty; 
    }

    img {
        width: 95%;
        height: 40vh;
        border: 5px solid rgb(109, 109, 225);
        border-radius: 25px;
        object-fit:cover;
        transition: all 0.5s;
        animation: animacion_entrada 1s ease forwards;
    }

    @keyframes animacion_entrada {
        from {
            height: 0;
            box-shadow: 0 0 0 0 rgb(109, 109, 225);
        }

        to {
            height: 40vh;
            box-shadow: 0 0 15px 0 rgb(87, 87, 202);
        }
    }

    span {
        transition: all 0.5s;
        animation: fade_in_texto 1s ease forwards;
    }

    @keyframes fade_in_texto {
        from {
            opacity: 0;
        }

        to {
            opacity: 100%;
        }
    }
</style>`;

export class BookDetail extends HTMLElement {
    shadow: ShadowRoot;

    constructor() {
        super();

        this.shadow = this.attachShadow({mode: 'open'});
        this.shadow.appendChild(template.content.cloneNode(true));
    }

    connectedCallback(): void {
        console.log('Elemento insertado en el DOM');
    }

    disconnectedCallback(): void {
        console.log('Elemento eliminado del DOM');
    }

    attributeChangedCallback(nombre: string | null, anterior: string | null, nuevo: string | null) {
        console.log(`El atributo ${nombre} cambió de ${anterior} a ${nuevo}`);
    }

    public show(book: Book): void {
        if(book) {
            this.shadow.innerHTML = `
            <style>
                .book-detail {
                    display: flex;
                    flex-direction: column;
                    flex-wrap: wrap;
                    overflow: auto;
                    overflow-x: hidden;
                    justify-content: center;
                    align-items: center;
                    gap: 15px;
                    width: 100%;
                    height: 75vh;
                    text-align: center;
                    text-wrap: pretty; 
                }

                img {
                    width: 95%;
                    height: 30vh;
                    border: 5px solid rgb(109, 109, 225);
                    border-radius: 25px;
                    object-fit:cover;
                    transition: all 0.5s;
                    animation: animacion_entrada 1s ease forwards;
                }

                @keyframes animacion_entrada {
                    from {
                        height: 0;
                        box-shadow: 0 0 0 0 rgb(109, 109, 225);
                    }

                    to {
                        height: 30vh;
                        box-shadow: 0 0 15px 0 rgb(87, 87, 202);
                    }
                }

                span {
                    transition: all 0.5s;
                    animation: fade_in_texto 1s ease forwards;
                }

                @keyframes fade_in_texto {
                    from {
                        opacity: 0;
                    }

                    to {
                        opacity: 100%;
                    }
                }
            </style>
            
            <div class="book-detail">
                <img src="${book.coverUrl}" alt="portada.jpg" loading="lazy">
                <span>Título: ${truncate(book.title, 50)}</span>
                <span>Autor/es: ${JoinList(book.authors, 2)}</span>
                <span>Año: ${book.year}</span>
                <span>Tema/s: ${JoinList(book.subjects, 5)}</span>
                <a href="https://openlibrary.org${book.id}" title="Enlace oficial del libro" target="_blank">¡Visita el enlace oficial del libro!</a>
            </div>`;

            contenedor_detalle_libro.style.display = 'flex';
        }
        else {
            this.hide();
        }
    }

    public hide(): void {
        contenedor_detalle_libro.style.display = 'none';
    }
}

customElements.define('book-detail', BookDetail);