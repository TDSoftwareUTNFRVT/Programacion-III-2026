import { SearchOptions } from "../models/Book";
import { BookDetail } from "./BookDetail";

type SearchCallback = (query: string) => void;
// Tipo que representa la función que se ejecuta cuando el usuario hace una búsqueda, recibe el texto de búsqueda

export class SearchBar {
    private container: HTMLElement;
    // Elemento HTML donde se va a renderizar la barra
    private options: SearchOptions;
    // Configuración de la barra (placeholder, mínimo de caracteres, etc)
    private onSearch: SearchCallback;
    // Callback que se ejecuta cuando hay que buscar
    private debounceTimer: ReturnType<typeof setTimeout> | null = null;
    // Guarda el temporizador para implementar el debounce (evitar que se dispare la búsqueda en cada tecla)
    pagina_actual: number;

    constructor(containerId: string, options: SearchOptions, onSearch: SearchCallback) {
        const el = document.getElementById(containerId);

        if(!el) throw new Error(`Contenedor "${containerId}" no encontrado`);

        this.container = el;
        this.options = options;
        this.onSearch = onSearch;
        this.pagina_actual = 1;
        this.render();

        // Busca el contenedor por id, si no existe lanza un error, guarda las opciones y el callback y llama a render para dibujar la barra
    }

    private render(): void {
        this.container.innerHTML = `
        <div class="search-bar">
        <input type="text" id="search-input"
        placeholder="${this.options.placeholder}"
        minlength="${this.options.minLength}"
        autocomplete="off" />
        <button id="search-btn">Buscar</button>
        </div>`;
        this.attachEvents();
    }

    private attachEvents(): void {
        const input = this.container.querySelector<HTMLInputElement>("#search-input");
        const btn = this.container.querySelector<HTMLButtonElement>("#search-btn");
        const contenedor_resultado = document.getElementById('results-grid') as HTMLDivElement;
        const detalle_libro = document.getElementById('book-detail') as BookDetail;

        input!.addEventListener("input", (e: Event) => {
            contenedor_resultado.innerHTML = '';

            // const target = e.target as HTMLInputElement;
            // this.handleDebounce(target.value);

            detalle_libro.hide();
        });

        btn!.addEventListener("click", () => {
            const query = input!.value.trim();
            if (query.length >= this.options.minLength) this.onSearch(query);
            // Si el texto cumple con el mínimo de caracteres, llama al callback onSearch(query)
            this.pagina_actual = 1;

            detalle_libro.hide();
        });
    }

    private handleDebounce(value: string): void {
        if(this.debounceTimer) clearTimeout(this.debounceTimer);
        // Si ya había un temporizador, lo cancela

        this.debounceTimer = setTimeout(() => {
            // Crea un nuevo temporizador que espera debounceMs milisegundos
            if(value.trim().length >= this.options.minLength) {
                // Solo si el texto tiene la longitud mínima, dispara la búsqueda, esto evita que se hagan demasiadas llamadas a la API mientras el usuario escribe
                this.onSearch(value.trim());
            }
        }, this.options.debounceMs);
    }
}