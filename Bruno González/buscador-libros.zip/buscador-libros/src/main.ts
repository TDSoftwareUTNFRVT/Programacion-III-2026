import { BookService } from "./services/BookService";
import { SearchBar } from "./components/SearchBar";
import { BookCardElement } from "./components/BookCardElement";
import { JoinList, tryCatch } from "./utils/helpers";
import { Book, AppState } from "./models/Book";
import { BookDetail } from "./components/BookDetail";

async function buscarLibros(query: string): Promise<void> {
    console.log(`Buscando: "${query}"...`);

    const [books, error] = await tryCatch(() => BookService.getInstance().searchBooks(query, 5));

    if(error) {
        console.error("Error al buscar:", error.message);
        return;
    }

    if(!books || books.length === 0) {
        console.log("No se encontraron resultados");
        return;
    }

    books.forEach(book => {
        console.log(`⬜ ${book.title}`);
        console.log(`Autores: ${JoinList(book.authors)}`);
        console.log(`Año: ${book.year ?? "Desconocido"}`);
        console.log(`Portada: ${book.coverUrl ?? "Sin portada"}`);
        console.log("---");
    });
}

buscarLibros("TypeScript programming");

let paginas_totales: number = 0;
const libros_permitidos_por_pagina: number = 10;

const indice_pagina = document.getElementById('page-index') as HTMLSpanElement;

const boton_anterior = document.getElementById('before-button') as HTMLButtonElement;

const boton_siguiente = document.getElementById('next-button') as HTMLButtonElement;

document.addEventListener('book:selected', (e: Event) => {
    const CustomEvent = e as CustomEvent<Book>;
    // El detail de este evento va a contener un objeto del tipo Book
    const libro = CustomEvent.detail;

    console.log(`Libro seleccionado: ${libro.title}`);
});

const state: AppState = {
    query: "", books: [], isLoading: false,
    error: null, totalResults: 0
}
// Guarda el estado de la aplicación, búsqueda actual, resultados, loading, error y total

const grid = document.getElementById("results-grid") as HTMLDivElement;
const status = document.getElementById("app-status") as HTMLElement;

const app_status_container = document.getElementById('app-status-container') as HTMLDivElement;

async function handleSearch(query: string): Promise<void> {
    state.query = query; state.isLoading = true; state.error = null;

    updateStatus("loading");
    updateStatusContainer("flex");
    clearGrid();

    const [books, error] = await tryCatch(() => BookService.getInstance().searchPage(query, searchBar.pagina_actual));

    state.isLoading = false;

    if(error) {
        state.error = error.message;
        updateStatus("error", error.message);
        return;
    }

    state.books = books?.books ?? [];

    paginas_totales = Math.ceil((books?.total ?? 0) / libros_permitidos_por_pagina);

    indice_pagina.textContent = `Página ${searchBar.pagina_actual} de ${paginas_totales}`;

    if(state.books.length === 0) {
        updateStatus("empty", "No se encontraron libros.");
        updateStatusContainer("flex");
        return;
    }

    console.log("Buscando:", query);

    updateStatus("idle");
    updateStatusContainer("none");
    renderBooks(state.books);
}

function renderBooks(books: Book[]): void {
    clearGrid();

    books.forEach(book => {
        const card = new BookCardElement();

        grid.appendChild(card);
        card.setBook(book);
    });

    console.log("Renderizando libros:", books);
}

function updateStatus(st: string, msg?: string): void {
    status.setAttribute("state", st);

    if(msg) status.setAttribute("message", msg);
}

function updateStatusContainer(display: string): void {
    app_status_container.style.display = display;
}

function clearGrid(): void {grid.innerHTML = '';}

document.addEventListener("book:selected", (e: Event) => {
    const { detail } = e as CustomEvent<Book>;

    console.log(`Libro seleccionado: ${detail.title}`);

    // Reto 6: Mostrar panel de detalle

    const detalle_libro = document.getElementById('book-detail') as BookDetail;
    detalle_libro.show(detail);
});

boton_anterior.addEventListener('click', async () => {
    if(searchBar.pagina_actual > 1) {
        searchBar.pagina_actual --;
        await handleSearch(state.query);

        const detalle_libro = document.getElementById('book-detail') as BookDetail;
        detalle_libro.hide();
    }
});

boton_siguiente.addEventListener('click', async () => {
    if(searchBar.pagina_actual < paginas_totales) {
        searchBar.pagina_actual ++;
        await handleSearch(state.query);

        const detalle_libro = document.getElementById('book-detail') as BookDetail;
        detalle_libro.hide();
    }
});

const searchBar = new SearchBar("search-container", {placeholder: "Buscar libros, autores...", minLength: 3, debounceMs: 400}, handleSearch);
// Pasa handleSearch como callback para ejecutar la búsqueda