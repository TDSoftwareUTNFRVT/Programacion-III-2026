export interface BookDoc {
    key: string;
    title: string;
    author_name?: string[];
    first_publish_year?: number;
    cover_i?: number;
    subject?: string[];
    isbn?: string[];
    language?: string;
    publisher?: string;
    number_of_pages_median?: number;
    ratings_average?: number;
}

// Representa la respuesta cruda de la API de Open Library, este modelo es fiel a la API, incluso con sus irregularidades

export interface ApiResponse<T> {
    numFound: number;
    // Cuántos resultados encontró la API
    start: number;
    // Indice de inicio, sirve para paginación
    docs: T[];
    // Array de resultados, tipado con el genérico <T>, dicho genérico permite reutilizar esta interfaz con distintos tipos de documentos
}

// Representa la estructura completa de la respuesta de búsqueda

export interface Book {
    readonly id: string;
    // No se puede modificar una vez asignado
    title: string;
    authors: string[];
    // Siempre es un array, aunque la API lo devuelva vacío
    year: number | null;
    coverUrl: string | null;
    // Ambos pueden ser nulos si no hay datos
    subjects: string[];
    rating?: number | null;
    pages?: number | null;
    // Ambos son opcionales, porque no siempre están disponibles
}

// Modelo interno, limpio y normalizado

export interface SearchOptions {
    placeholder: string;
    // Texto que aparece en el input
    minLength: number;
    // Mínimo de caracteres para disparar la búsqueda
    debounceMs: number;
    // Tiempo de espera antes de ejecutar la búsqueda (para evitar llamadas excesivas)
}

// Configuración para la barra de búsqueda (SearchBar)

export interface AppState {
    query: string;
    // El texto que el usuario está escribiendo
    books: Book[];
    // Los resultados actuales
    isLoading: boolean;
    // Indica si es está esperando la respuesta de la API
    error: string | null;
    // Guarda un mensaje de error si algo falla
    totalResults: number;
    // Número total de libros encontrados
}

// Representa el estado global de la aplicación