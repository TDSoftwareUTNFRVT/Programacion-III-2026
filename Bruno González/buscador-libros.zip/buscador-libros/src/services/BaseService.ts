export abstract class BaseService {
    // Significa que no se puede instanciar directamente, solo sirve para que otras clases la extiendan
    protected readonly baseUrl: string;
    // Propiedad accesible en esta clase y en las subclases, pero no desde afuera. readonly asegura que no se pueda modificar después de asignarla
    private readonly timeout: number;
    // Propiedad privada, solo accesible dentro de esta clase, define cuánto tiempo esperar antes de considerar que la conexión "se colgó"

    constructor(baseUrl: string, timeout: number = 5000) {
        this.baseUrl = baseUrl;
        this.timeout = timeout
    }

    protected buildUrl(endpoint: string, params: Record<string, string>): string {
        // (Record<string, string>): Significa que params es un objeto con pares clave-valor
        const url = new URL(`${this.baseUrl}${endpoint}`);
        // Usa URL para armar la dirección

        Object.entries(params).forEach(([key, val]) => {
            url.searchParams.append(key, val);
            // Usa searchParams.append para agregar los parámetros
        });
        //Object.entries lo convierte en un array de arrays

        return url.toString();
    }
    // Construye una URL completa con parámetros de búsqueda

    protected abstract fetchData<T>(endpoint: string): Promise<T>;
    // Método abstracto fetchData, no tiene implementación aquí, obliga a las subclases a definir cómo se hace el fetch, el <T> indica que es genérico, osea que puede devolver distintos tipos de datos según lo que se necesite

    public getStatus(): string {
        return `Conectado a ${this.baseUrl} (timeout: ${this.timeout}ms)`;
        // Devuelve un string con el estado del servicio
    }
}