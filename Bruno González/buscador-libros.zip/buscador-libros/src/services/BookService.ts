import { BaseService } from "./BaseService";
import { ApiResponse, BookDoc, Book } from "../models/Book";

export class BookService extends BaseService {
    // Hereda la lógica común (URL base, buildUrl, fetchData)
    private static instance: BookService;

    private constructor() {
        super('https://openlibrary.org', 8000);
    }
    // Evita que se pueda hacer new BookService() desde afuera

    public static getInstance(): BookService {
        if(!BookService.instance) {
            BookService.instance = new BookService();
        }

        return BookService.instance;
    }
    // Implementa el patrón Singleton, siempre devuelve la misma instancia, esto asegura que toda tu app use un único servicio centralizado evitando duplicados y manteniendo consistencia

    protected async fetchData<T>(endpoint: string): Promise<T> {
        const response = await fetch(endpoint);

        if(!response.ok) {
            throw new Error(`Error HTTP: ${response.status} ${response.statusText}`);
        }

        return response.json() as Promise<T>;
        // Convierte el JSON en el tipo genérico <T>
    }

    public async searchBooks(query: string, limit: number = 10): Promise<Book[]> {
        const url = this.buildUrl("/search.json", {
            q: query,
            limit: limit.toString(),
            fields: "key, title, author_name, first_publish_year, cover_i, subject"
        });
        // Usa buildUrl para armar la URL con parámetros(q, limit, fields)

        const data = await this.fetchData<ApiResponse<BookDoc>>(url);
        // Llama a fetchData para obtener los resultados
        // Se usa con <> porque esos <> son genéricos, ya que fetchData es de tipo T o genérico, permitiendo que devuelva cualquier tipo de dato siempre envuelto en una Promise (lo último sólo en este caso porque así esta armado fetchData)
        // Llamando a fetchData acá le decimos a TS "Voy a llamar a fetchData y espero que me devuelva un Promise<ApiResponse<BookDoc>>" haciendo que data tenga el tipo correcto
        // El (url) es el valor concreto que se le pasa al método

        // ApiResponse también tiene los <> porque también usa genéricos
        return data.docs.map(doc => this.mapToBook(doc));
        // Convierte cada BookDoc en un Book interno usando mapToBook
    }

    private mapToBook(doc: BookDoc): Book {
        return {
            id: doc.key,
            title: doc.title,
            authors: doc.author_name ?? ["Autor desconocido"],
            year: doc.first_publish_year ?? null,
            coverUrl: doc.cover_i ? `https://covers.openlibrary.org/b/id/${doc.cover_i}-M.jpg` : null,
            subjects: doc.subject?.slice(0, 5) ?? []
        };
    }
    // Convierte un BookDoc en un Book limpio, si no hay autores pone "Autor desconocido", si no hay año usa null, si hay cover_i, construye la URL de la portada y limita los temas a 5.

    // Esto es un DTO (Data Transfer Object): separa datos externos de internos

    public async getBooksByAuthor(authorName: string): Promise<Book[]> {
        const url = this.buildUrl("/search.json", {
            author: authorName,
            fields: "key, title, author_name, first_publish_year, cover_i, subject"
        });

        const data = await this.fetchData<ApiResponse<BookDoc>>(url);
        return data.docs.map(doc => this.mapToBook(doc));
    }
    // Similar a searchBooks, pero usa el parámetro author en lugar de q y devuelve todos los libros de un autor específico

    public async searchPage(query: string, page: number, pageSize: number = 10): Promise<{books: Book[], total: number}> {
        const offset = (page - 1) * pageSize;
        // Calcula el offset según la página y el tamaño

        const url = this.buildUrl("/search.json", {
            q: query,
            limit: pageSize.toString(),
            offset: offset.toString(),
            fields: "key, title, author_name, first_publish_year, cover_i, subject"
        });
        // Llama a la API con limit y offset

        const data = await this.fetchData<ApiResponse<BookDoc>>(url);
        return {
            books: data.docs.map(doc => this.mapToBook(doc)),
            // Resultados de esa página
            total: data.numFound
            // Número total de resultados
        };
        // Devuelve un objeto
    }
}