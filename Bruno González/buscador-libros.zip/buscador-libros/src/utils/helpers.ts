export function truncate(text: string, maxLength: number = 100): string {
    if(text.length <= maxLength) return text;
    // Si el texto tiene menos carácteres que maxLength lo devuelve tal cual
    return text.slice(0, maxLength).trimEnd() + "...";
    // Si el texto es más largo que maxLength lo corta y le agrega "..."
}
// Recorta un texto si es demasiado largo

export function JoinList(items: string[], max: number = 3): string {
    if(items.length === 0) return "Sin información";
    // Si el array está vacío devuelve "Sin información"

    const visible = items.slice(0, max);
    // Elementos que van a ser visibles
    const remaining = items.length - max;
    // Elementos sobrantes
    const base = visible.join(", ");
    return remaining > 0 ? `${base} y ${remaining} más` : base;
}
// Convierte un array de strings en una lista legible

export async function tryCatch<T>(
    fn: () => Promise<T>
): Promise<[T | null, Error | null]> {
    try {
        const data = await fn();
        return [data, null];
        // Si sale bien
    } catch (err) {
        const error = err instanceof Error ? err: new Error(String(err));
        return [null, error];
        // Si sale mal
    }
    // Devuelve una tupla [data, error]
}
// Envuelve una función async y captura errores sin necesidad de escribir try/catch en cada llamada

export function getCoverUrl(coverId: number | undefined): string {
    if(!coverId) return "/public/no-cover.png";
    // Si no hay coverId devuelve una imágen por defecto
    return `https://covers.openlibrary.org/b/id/${coverId}-M.jpg`;
    // Si hay arma la URL oficial de Open library
}
// Construye la URL de la portada del libro