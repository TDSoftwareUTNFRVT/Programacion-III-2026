const inputBusqueda = document.getElementById("inputBusqueda");
const selectCantidad = document.getElementById("limite");
const btnBuscar = document.getElementById("buscar");
const results = document.getElementById("results");
const contador = document.getElementById("contador");
const btnLimpiar = document.getElementById("limpiar");

let paginaActual = 1;

class LibroAPI {

    static BASE_URL = "https://openlibrary.org/search.json";

    constructor() {
        this.cache = new Map();
    }

    async #fetchJSON(url) {

        if (this.cache.has(url)) {
            return this.cache.get(url);
        }

        const respuesta = await fetch(url);

        if (!respuesta.ok) {
            throw new Error(`Error ${respuesta.status}`);
        }

        const data = await respuesta.json();

        this.cache.set(url, data);

        return data;
    }

    async getLibros(query, page = "", limit = "") {

    let url = LibroAPI.BASE_URL + "?q=" + query;
    if (page) {url += `&page=${page}`;}
    if (limit) {url += `&limit=${limit}`;}

    const data = await this.#fetchJSON(url);

    return data.docs;
}
}

class Tarjeta extends HTMLElement {

    static get observedAttributes() {
        return ["title", "author", "year", "cover-url"];
    }

    constructor() {
        super();
        this.shadow = this.attachShadow({mode: "open"});
    }

    connectedCallback() {
        this.render();
    }

    attributeChangedCallback() {
        this.render();
    }

    render() {
        const title = this.getAttribute("title") ||"Sin título";
        const author = this.getAttribute("author") || "Autor desconocido";
        const year = this.getAttribute("year") || "Desconocido";
        const coverUrl = this.getAttribute("cover-url") || "";

        const placeholder = "./chacarita.jpg";

        this.shadow.innerHTML = `
            <style>

                .book-card{
                    width:220px;
                    border:1px solid #ccc;
                    border-radius:8px;
                    padding:10px;
                    box-sizing:border-box;
                }

                img{
                    width:100%;
                    height:300px;
                    object-fit:cover;
                }

                h3{
                    font-size:16px;
                }

            </style>

            <div class="book-card">

                <img src="${coverUrl || placeholder}" alt="${title}">
                <h3>${title}</h3>
                <p>${author}</p>
                <p>${year}</p>

            </div>
        `;
    }
}

customElements.define("book-card", Tarjeta);

const api = new LibroAPI();

async function renderizarLibros() {
    const texto = inputBusqueda.value.trim();
    if (!texto) return;

    const limite = Number(selectCantidad.value);
    const libros = await api.getLibros(texto, paginaActual);

    results.innerHTML = "";

    libros.slice(0, limite).forEach(libro => {
            const tarjeta =
                document.createElement("book-card");
            tarjeta.setAttribute("title",libro.title || "");
            tarjeta.setAttribute("author",libro.author_name?.[0] ||"Autor desconocido");
            tarjeta.setAttribute("year",libro.first_publish_year ||"");

            const portada =libro.cover_i? `https://covers.openlibrary.org/b/id/${libro.cover_i}-M.jpg`: "";

            tarjeta.setAttribute("cover-url",portada);

            results.appendChild(tarjeta);
        });

    contador.textContent = `Página ${paginaActual}`;
}

btnBuscar.addEventListener("click",() => {
        paginaActual = 1;
        renderizarLibros();
    }
);

btnLimpiar.addEventListener("click",() => {
        inputBusqueda.value = "";
        results.innerHTML = "";
        contador.textContent = "";
    });
document.getElementById("siguiente").addEventListener("click",() => {
            paginaActual++;
            renderizarLibros();
        }
    );

document.getElementById("anterior").addEventListener("click",() => {
            if (paginaActual > 1) {
                paginaActual--;
                renderizarLibros();
            }
        }
    );
