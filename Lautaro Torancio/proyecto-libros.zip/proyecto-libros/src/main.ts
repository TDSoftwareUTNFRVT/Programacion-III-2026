import {BookService} from "./services/BookService";
import {SearchBar} from "./components/SearchBar";
import {BookCardElement} from "./components/BookCardElement";
import { tryCatch } from "./utils/helpers";
import { Book, AppState} from "./models/Book";

const state: AppState = {
    query:"",
    books: [],
    isLoading: false,
    error: null,
    totalResults: 0
};

const grid = document.getElementById("results-grid") as HTMLElement;
const status = document.getElementById("app-status") as HTMLElement;

async function handleSearch(query: string): Promise<void> {
    state.query = query;
    state.isLoading = true;
    state.error = null;
    updateStatus("loading");
    clearGrid();

    const [books, error] = await tryCatch(() => BookService.getInstance().searchBooks(query));
    state.isLoading = false;
    if (error) {
        state.error = error.message;
        updateStatus("error", error.message);
        return;
    }
    state.books = books ?? [];
    if (state.books.length === 0) {
        updateStatus("empty", "no se encontraron resultados");
        return;
    }
    updateStatus("idle");
    renderBooks(state.books);
}

function renderBooks(books: Book[]): void {
    books.forEach(book => {
        const card = new BookCardElement();
        card.setBook(book);
        grid.appendChild(card);
    });
}

function updateStatus(st: string, msg?: string): void {
    status.setAttribute("state", st);
    if (msg) status.setAttribute("message", msg);
}

function clearGrid(): void {grid.innerHTML = "";}

document.addEventListener("book:selected", (e: Event) => {
    const {detail} = e as CustomEvent<Book>;
    console.log("Libro seleccionado:", detail.title);
});

new SearchBar("search-container", {
    placeholder: "Buscar libros...",
    minLength: 3,
    debounceMs: 400
}, handleSearch);