export interface BookDoc{
    key:string;
    tittle:string;
    author_name?: string[];
    first_publish_year?: number;
    cover_i?:string;
    isbn?:string[];
    languaje?: string[];
    publisher?: string[];
    subject?: string[];
    number_of_pages_median?: number;
    ratings_average?: number
}

export interface ApiResponse<T>{
    numFound: number;
    start:number;
    docs: T[];
}

export interface Book{
    readonly id: string;
    title:string;
    authors:string[];
    year:number | null;
    coverUrl:string | null;
    subjects: string[]
}

export interface SearchOptions{
    placeholder: string;
    minLength: number;
    debounceMs: number;
}

export interface AppState{
    query: string;
    books: Book[];
    isLoading: boolean;
    error: string | null;
    totalResults: number;
}