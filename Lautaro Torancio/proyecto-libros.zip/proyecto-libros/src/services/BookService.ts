import { BaseService } from './BaseService';
import { ApiResponse, BookDoc, Book } from "../models/Book";

export class BookService extends BaseService{
    private static instance: BookService;
    private constructor (){
        super("https://openlibrary.org", 8000);
    }

    public static getInstance (): BookService{
        if(!BookService.getInstance) {
            BookService.instance = new BookService();
        }
        return BookService.instance;
    }
    protected async fetchData<T>(endpoint: string): Promise<T>{
        const response = await fetch(endpoint);
        if(!response.ok){
            throw new Error(`Error HTTP: ${response.status} ${response.statusText}`);
        }
        return response.json() as Promise<T>;
    }
    public async searchBooks(query: string, limit: number = 10): Promise<Book[]>{
        const url = this.buildUrl("/search.json", {
            q: query,
            limit:limit.toString(),
            fields: "key,title,author_name,first_publish_year,cover_i,subject"
        });
        const data = await this.fetchData<ApiResponse<BookDoc>>(url);
        return data.docs.map(doc => this.mapToBook(doc));
    }
    private mapToBook (doc: BookDoc): Book{
        return{
            id: doc.key,
            title: doc.tittle,
            authors: doc.author_name ?? ["Autor Desconocido"],
            year: doc.first_publish_year ?? null,
            coverUrl: doc.cover_i? 
            `https://covers.openlibrary.org/b/id/${doc.cover_i}-M.jpg`: null,
            subjects: doc.subject?.slice(0, 5) ?? [],

        }
    }
}